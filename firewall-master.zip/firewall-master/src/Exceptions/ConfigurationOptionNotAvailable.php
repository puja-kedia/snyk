<?php

namespace PragmaRX\Firewall\Exceptions;

use Exception;

class ConfigurationOptionNotAvailable extends Exception
{
}
